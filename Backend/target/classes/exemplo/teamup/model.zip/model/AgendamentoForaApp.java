package exemplo.teamup.model;

import java.util.Date;

public class AgendamentoForaApp {

	private long id;
	private Date dataIni;
	private Date dataFim;
	private String nomeReservante;
	private String telefoneReservante;
	
}
