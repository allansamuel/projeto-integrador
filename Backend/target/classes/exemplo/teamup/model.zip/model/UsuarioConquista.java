package exemplo.teamup.model;

public class UsuarioConquista {

	private long id;
	private EtapaConquista etapaConquista;
	private Usuario usuario;
	private Conquista conquista;
	
	
}
