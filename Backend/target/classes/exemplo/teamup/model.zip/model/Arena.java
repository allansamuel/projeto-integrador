package exemplo.teamup.model;

public class Arena {
	private long id;
	private String nome;
	private String urlLogo;
	private String email;
	private String senha;
	private Agenda agenda;

}
