package exemplo.teamup.model;

public enum Modalidade {

	INDIVIDUAL, COLETIVO;
}
