package exemplo.teamup.model;

public enum StatusPartida {
	DESAFIADO, AGENDADA, CANCELADA, CONCLUIDA;

}
