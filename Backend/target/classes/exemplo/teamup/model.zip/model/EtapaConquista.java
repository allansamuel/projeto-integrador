package exemplo.teamup.model;

public enum EtapaConquista {

	PRIMEIRA(1), SEGUNDA(2), TERCEIRA(3);
	
	private int etapaConquista;
	
	EtapaConquista(int etapaConquista) {
		this.etapaConquista = etapaConquista;
	}	
}
