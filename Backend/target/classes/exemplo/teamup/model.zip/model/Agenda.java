package exemplo.teamup.model;

import java.util.List;

public class Agenda {
	private long id;
	private List<AgendamentoForaApp> agendamentosForaApp;
	private Arena arena;
	private List<Partida> agendaPartidasApp;
	
}
