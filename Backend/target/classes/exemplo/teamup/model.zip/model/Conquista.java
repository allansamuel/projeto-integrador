package exemplo.teamup.model;

import java.util.Date;

public class Conquista {

	private long id;
	private String titulo;
	private double pontuacao;
	private String urlImagem;
	// REVER NECESSIDADE DO TIPO E CRIAR ENUM CASO NECESSÁRIO
	//private String tipo;
	private Date dataConquista;
	
}
