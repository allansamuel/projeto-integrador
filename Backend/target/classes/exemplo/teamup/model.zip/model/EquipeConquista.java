package exemplo.teamup.model;

public class EquipeConquista {

	private long id;
	private EtapaConquista etapaConquista;
	private Equipe equipe;
	private Conquista conquista;
	
}
