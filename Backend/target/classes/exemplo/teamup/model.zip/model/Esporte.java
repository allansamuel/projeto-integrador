package exemplo.teamup.model;

public class Esporte {
	
	private long id;
	private String nome;
	private Modalidade modalidade;
	private String urlImagem;
}
